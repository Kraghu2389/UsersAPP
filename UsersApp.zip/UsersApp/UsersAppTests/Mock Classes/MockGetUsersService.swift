//
//  MockGetUsersService.swift
//  UsersAppTests
//
//  Created by Raghavender Reddy on 01/03/25.
//

import Foundation
import Combine
@testable import UsersApp

class MockGetUsersService: UserServiceProtocol {
    var mockFileType: GetUsersMockFileType?
    
    func fetchUsers(urlString: String) -> AnyPublisher<[User], UserError> {
        
        return Future<[User], UserError> { [weak self] promise in
            guard let mockFile = self?.mockFileType else {
                promise(.failure(.missingDependency))
                return
            }
            
            let response = UnitTestsHelper().getUsersResponse(mockFileType: mockFile)
            guard let usersResponse = response else {
                switch mockFile {
                case .failure:
                    promise(.failure(.other))
                    break
                default:
                    promise(.failure(.other))
                }
                return
            }
            promise(.success(usersResponse))
        }
        .eraseToAnyPublisher()
    }
}
