//
//  Bundle+Extension.swift
//  UsersAppTests
//
//  Created by Raghavender Reddy on 01/03/25.
//

import Foundation

extension Bundle {
    
    func readCOntentsOfFile(_ file: String) -> Data? {
        guard let url = self.url(forResource: file, withExtension: nil) else {
            return nil
        }
        do {
            let data = try Data(contentsOf: url)
            return data
        } catch {
            return nil
        }
    }
}
