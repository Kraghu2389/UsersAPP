//
//  UnitTestsHelper.swift
//  UsersAppTests
//
//  Created by Raghavender Reddy on 01/03/25.
//

import Foundation
@testable import UsersApp

enum GetUsersMockFileType: String {
    case succes =  "Get_Users_success.json"
    case failure
}

class UnitTestsHelper {
    func getUsersResponse(mockFileType: GetUsersMockFileType) -> [User]? {
        guard let array = getArray(from: mockFileType.rawValue) else { return [] }
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: array, options: [])
            let response = try JSONDecoder().decode([User].self, from: jsonData)
            return response
        } catch {
            print("Error decoding users data: \(error)")
            return []
        }
    }

    func getArray(from mockResponseFile: String) -> [[String: Any]]? {
        let mockData = Bundle(for: type(of: self)).readCOntentsOfFile(mockResponseFile)
        guard let data = mockData else { return nil }
        do {
            let jsonObject = try JSONSerialization.jsonObject(with: data, options: [])
            return jsonObject as? [[String: Any]]
        } catch {
            print("Error serializing JSON: \(error)")
            return nil
        }
    }
}
