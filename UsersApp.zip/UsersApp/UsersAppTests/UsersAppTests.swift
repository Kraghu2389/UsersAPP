//
//  UsersAppTests.swift
//  UsersAppTests
//
//  Created by Raghavender Reddy on 01/03/25.
//

import XCTest
import Combine
import Resolver
@testable import UsersApp

final class UsersAppTests: XCTestCase {

    @LazyInjected private var service: UserServiceProtocol
    private var subscriptions: Set<AnyCancellable> = []

    var mockService: MockGetUsersService? {
        service as? MockGetUsersService
    }
    
    override func setUpWithError() throws {
        Resolver.defaultScope = .shared
        Resolver.register{ UnitTestsHelper() }
        Resolver.register { MockGetUsersService() }
            .implements(UserServiceProtocol.self)
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    func test_fetch_users_success() throws {
        mockService?.mockFileType = .succes
        let viewModel = UsersViewModel()
        XCTAssertEqual(viewModel.users.count, 0)
                
        let expectation = expectation(description: "users fetching")
        viewModel.$users
            .dropFirst()
            .sink { _ in
                expectation.fulfill()
            }.store(in: &subscriptions)
        waitForExpectations(timeout: 10)
        
        XCTAssertTrue(viewModel.users.count > 0)
        XCTAssertEqual(viewModel.users.count, 10)
    }
    
    func test_fetch_users_failure() throws {
        mockService?.mockFileType = .failure
        let viewModel = UsersViewModel()
        XCTAssertEqual(viewModel.users.count, 0)
                
        let expectation = expectation(description: "users fetching with error")
        viewModel.$users
            .dropFirst()
            .sink { _ in
                expectation.fulfill()
            }.store(in: &subscriptions)
        waitForExpectations(timeout: 10)
        
        XCTAssertTrue(viewModel.users.count == 0)
        XCTAssertEqual(viewModel.users.count, 0)
    }

    func test_isLoading_State_on_fetch() {
        mockService?.mockFileType = .succes
        let viewModel = UsersViewModel()
        XCTAssertTrue(viewModel.isLoading)
        
        let expectation = expectation(description: "users fetching ")
        viewModel.$users
            .dropFirst()
            .sink { _ in
                expectation.fulfill()
            }.store(in: &subscriptions)
        waitForExpectations(timeout: 10)
        XCTAssertFalse(viewModel.isLoading)
    }
}

