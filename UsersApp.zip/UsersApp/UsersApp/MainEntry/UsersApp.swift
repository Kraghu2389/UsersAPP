//
//  UsersAppApp.swift
//  UsersApp
//
//  Created by Raghavender Reddy on 01/03/25.
//

import SwiftUI

@main
struct UsersApp: App {
    var body: some Scene {
        WindowGroup {
            UsersListScreen()
        }
    }
}
