//
//  ServiceURLs.swift
//  UsersApp
//
//  Created by Raghavender Reddy on 01/03/25.
//

enum ServiceURLs {
    static let getUsersURL = "https://jsonplaceholder.typicode.com/users"
}
