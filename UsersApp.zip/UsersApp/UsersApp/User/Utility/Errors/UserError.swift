//
//  UserError.swift
//  UsersApp
//
//  Created by Raghavender Reddy on 01/03/25.
//

import Foundation

enum UserError: Error {
    case invalidURL
    case invalidResponse
    case other
    case missingDependency
}
