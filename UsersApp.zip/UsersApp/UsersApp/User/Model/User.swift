//
//  User.swift
//  UsersApp
//
//  Created by Raghavender Reddy on 01/03/25.
//

import Foundation

struct User: Codable {
    let id: Int
    let username: String?
    let email: String?
    let phone: String?
}
