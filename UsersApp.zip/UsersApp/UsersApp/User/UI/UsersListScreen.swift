//
//  UsersListScreen.swift
//  UsersApp
//
//  Created by Raghavender Reddy on 01/03/25.
//

import SwiftUI

struct UsersListScreen: View {
    @StateObject var viewModel = UsersViewModel()

    var body: some View {
        NavigationView {
            Group {
                if viewModel.isLoading {
                    ProgressView()
                } else {
                    List(viewModel.users, id: \.id) { user in
                        UserRow(user: user)
                    }
                }
            }
            .navigationBarTitleDisplayMode(.automatic)
            .navigationTitle("Users")
        }
        .alert(viewModel.errorMessage ?? "", isPresented: $viewModel.showError, actions: {})
    }
}

#Preview {
    UsersListScreen(viewModel: .init())
}
