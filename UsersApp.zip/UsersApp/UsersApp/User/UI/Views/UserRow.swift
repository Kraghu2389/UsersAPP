//
//  UserRow.swift
//  UsersApp
//
//  Created by Raghavender Reddy on 01/03/25.
//

import SwiftUI

struct UserRow: View {
    let user: User
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(user.username ?? "")
                .font(.headline)
            Text(user.email ?? "")
                .font(.subheadline)
            Text(user.phone ?? "")
                .font(.subheadline)
        }
        .padding()
    }
}

#Preview {
    UserRow(user: User(id: 0,
                       username: "John",
                       email:"John@gmail.com",
                       phone: "9876545678"))
}
