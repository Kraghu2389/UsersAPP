//
//  UserService.swift
//  UsersApp
//
//  Created by Raghavender Reddy on 01/03/25.
//

import Foundation
import Combine
import Resolver

class UserService: UserServiceProtocol {
    @Injected var networkClient: NetworkClient

    func fetchUsers(urlString: String) -> AnyPublisher<[User], UserError> {
        guard let url = URL(string: urlString) else {
            return Fail(error: UserError.invalidURL).eraseToAnyPublisher()
        }
        return networkClient.fetchData(from: url)
            .decode(type: [User].self, decoder: JSONDecoder())
            .mapError { $0 as? UserError ?? .other }
            .eraseToAnyPublisher()
    }
}

