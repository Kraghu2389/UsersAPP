//
//  FetchUsersDataUseCase.swift
//  UsersApp
//
//  Created by Raghavender Reddy on 01/03/25.
//

import Foundation
import Combine
import Resolver

class FetchUsersDataUseCase: FetchUsersDataUseCaseProtocol {
    
    @Injected private var userService: UserServiceProtocol
    
    func callAsFunction() -> AnyPublisher<[User], UserError> {
        return userService.fetchUsers(urlString: ServiceURLs.getUsersURL)
    }
}
