//
//  FetchUsersDataUseCaseProtocol.swift
//  UsersApp
//
//  Created by Raghavender Reddy on 01/03/25.
//

import Foundation
import Combine

protocol FetchUsersDataUseCaseProtocol {
    func callAsFunction() -> AnyPublisher<[User], UserError>
}
