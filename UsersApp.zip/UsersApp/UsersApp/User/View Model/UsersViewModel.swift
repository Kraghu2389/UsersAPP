//
//  UsersViewModel.swift
//  UsersApp
//
//  Created by Raghavender Reddy on 01/03/25.
//

import Foundation
import Combine
import Resolver

class UsersViewModel: ObservableObject {
    @Published var users: [User] = []

    private var cancellables = Set<AnyCancellable>()
    @Injected private var fetchUsersDataUseCase: FetchUsersDataUseCaseProtocol
    @Published var isLoading: Bool = false
    @Published var showError: Bool = false
    @Published var errorMessage: String?

    init() {
        fetchUsers()
    }
}

extension UsersViewModel {
    func fetchUsers() {
        isLoading = true
        fetchUsersDataUseCase()
            .sink(receiveCompletion: { [weak self] completion in
                switch completion {
                case .failure(let error):
                    self?.handleError(error: error)
                case .finished:
                    print("finished execution")
                }

            }, receiveValue: { [weak self] users in
                self?.handleUsersResponse(response: users)
            })
            .store(in: &cancellables)
    }
    
    private func handleUsersResponse(response: [User]) {
        DispatchQueue.main.async { [weak self] in
            self?.isLoading = false
            self?.users = response
        }
    }
    
    private func handleError(error: Error) {
        print(error.localizedDescription)
        DispatchQueue.main.async { [weak self] in
            self?.isLoading = false
            self?.showError = true
            self?.errorMessage = error.localizedDescription
        }
    }
}
