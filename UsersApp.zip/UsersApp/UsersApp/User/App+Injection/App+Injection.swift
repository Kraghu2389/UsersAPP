//
//  App+Injection.swift
//  UsersApp
//
//  Created by Raghavender Reddy on 01/03/25.
//

import Foundation
import Resolver

extension Resolver: ResolverRegistering {
    public static func registerAllServices() {
        registerDependencies()
    }

    static func registerDependencies() {
        register { UserService() }
            .implements(UserServiceProtocol.self)
        
        register { FetchUsersDataUseCase() }
            .implements(FetchUsersDataUseCaseProtocol.self)
        
        register { HttpClient() }
            .implements(NetworkClient.self)
    }
}
